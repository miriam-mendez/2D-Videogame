#pragma once

class Activable {
public:
    virtual void set(bool active) = 0;
};